#!/bin/bash

RHTOOLSDIR=/opt/rh/devtoolset-7/root/usr/bin
export CC=$RHTOOLSDIR/gcc  
export CPP=$RHTOOLSDIR/cpp
export CXX=$RHTOOLSDIR/c++
# gcc-10 flipped a default from -fcommon to -fno-common
#!!! -Wconversion -Wsign-compare
export CFLAGS="-g -fno-common -finstrument-functions -Woverlength-strings -Wstrict-overflow -Wuninitialized"
/bin/mv -f $RHTOOLSDIR/sudo $RHTOOLSDIR/sudo.orig 2> /dev/null

DESTDIR=/opt/monit
DAEMON=$DESTDIR/bin/monit


function strip()
{
	echo
	echo "--- STRIP -- $*"
	/bin/ls -la $*
	/usr/bin/strip --preserve-dates --strip-debug --strip-unneeded $*
	/bin/ls -la $*
}


function press()
{
	local ex=$?
	local msg=$1

	echo -e "\n------------------------------------------------------------------"
	echo "$msg : exit code $ex"
	echo
	[ $ex -eq 0 ] || exit $ex
}



#-----------------------------------------------------------------
# MAIN

if ! test -x $CC; then
	echo "Installing RedHat gcc toolset v7 to $RHTOOLSDIR"
	yum --quiet install centos-release-scl devtoolset-7-make devtoolset-7-gcc-c++ devtoolset-7-strace
fi
test -x $CXX || press "File not found: $CXX"

# new gcc, autoconf, automake
export PATH=$RHTOOLSDIR:/usr/local/bin:$PATH

echo "Installing other system utilities, the packages are fetched to /tmp"
echo "On centos 6 no problem, these new binaries will not overwrite the OS builtins"
for name in autoconf automake libtool tcc; do
	if ! test -x /usr/local/bin/$name; then
		yum --quiet erase $name
		pushd /tmp
			[ "$name" == "autoconf" ] && ver=2.69
			[ "$name" == "automake" ] && ver=1.15.1
			[ "$name" == "libtool" ] && ver=2.4.6
			i=$name-$ver
			wget http://ftp.gnu.org/gnu/$name/$i.tar.gz
			tar xf $i.tar.gz
			cd $i
			./configure && make -j$(nproc) && make install	> /dev/null
			press "install $name"
		popd

		[ "$name" == "autoconf" ] && ver=2.69.0
		$FOLDER/mk_rpm.sh $name $ver /usr/local/bin/$name $FOLDER
	fi
done

export PATH=$PATH:/usr/local/share/automake-1.15

#-----------------------------------------------------------------

yum --quiet install pam-devel openssl-devel

if ! test -f monitrc; then
	echo "File monitrc not found!"
	echo "Run this script from the monit source directory."
	exit 1
fi

if test -f src/config.h; then
	make clean > /dev/null
else
	./bootstrap		|| press bootstrap
fi

unzip $1	|| press unzip
if ! test -f src/tftp.c; then
	echo "Cannot unzip the archive: $1"
	exit 1
fi
chown -R u+rw .

./configure --prefix=$DESTDIR								> /tmp/mk_configure.log
press configure

sed -i 's/5.26.0"/5.26.1"/g' src/config.h
grep '5.26' src/config.h							|| press config.h
read

grep -i tftp src/tokens.h	|| read -p "!!! tokens: tftp ?"

make -j$(nproc)								> /tmp/mk_make.log
press make

read -p "Install to $DESTDIR ? [y/N] "
[ "$REPLY" == "y" ] || exit 1

make install
press "make install"

strip $DAEMON
test -x $DAEMON || press "not executable: $DAEMON"
$DAEMON -V
